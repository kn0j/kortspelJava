

import java.util.Scanner;

public class PlayingCardGame
{
    static PlayingCardDeck deck = new PlayingCardDeck();

    public static void Play()
    {
        showMenu();

        Play();
    }

    private static void showMenu()
    {
        System.out.println("Press 1 to play\nPress 2 for rules\nPress 3 to exit.");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        if(input.contains("1"))
        {
            populateDeck();
            deck.Shuffle();
            playerAction();
        }
        else if(input.contains("2"))
        {
            showRules();
        }
        else System.exit(0);
    }

    private static void showRules()
    {
        System.out.println("Dealer shows a card, if you believe that the next card has a \nhigher value press y on the keyboard, otherwise press n.");
    }

    private static void populateDeck()
    {
        for(int value = 1; value <= 13; value++)
        {
            deck.Add(new PlayingCard(Suits.Clubs, value));
            deck.Add(new PlayingCard(Suits.Hearts, value));
            deck.Add(new PlayingCard(Suits.Diamonds, value));
            deck.Add(new PlayingCard(Suits.Spades, value));
        }
    }

    private static void playerAction()
    {
        PlayingCard faceUpCard = deck.Draw();
        faceUpCard.Reveal();
        faceUpCard.Deal();

        PlayingCard faceDownCard = deck.Draw();
        faceDownCard.Deal();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Do you believe the card is higher than the card shown? y/n");
        String input = scanner.nextLine();
        faceDownCard.Reveal();
        faceDownCard.Deal();

        if(input.contains("y") || input.contains("Y"))
        {
            if(faceDownCard.Value > faceUpCard.Value)
            {
                System.out.println("You won!");
            }
            else if(faceDownCard.Value == faceUpCard.Value)
            {
                if(faceDownCard.getSuitValue() > faceUpCard.getSuitValue())
                {
                    System.out.println("You won!");
                }
                else System.out.println("You lost!");
            }
            else System.out.println("You lost!");
        }

        if(input.contains("n") || input.contains("N"))
        {
            if(faceDownCard.Value < faceUpCard.Value)
            {
                System.out.println("You won!");
            }
            else if(faceDownCard.Value == faceUpCard.Value)
            {
                System.out.println("It's a tie!");
            }
            else System.out.println("You lost!");
        }
    }
}
