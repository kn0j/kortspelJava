enum Suits
{
    Hearts,
    Spades,
    Diamonds,
    Clubs
}

public class PlayingCard
{
    public Boolean Visible = false;
    public Suits Suit = Suits.Hearts;
    public int Value = 1;

    public PlayingCard(Suits s, int val)
    {
        this.Suit = s;
        this.Value = val;
    }

    public void Reveal()
    {
        Visible = true;
    }

    public void Deal()
    {
        if(Visible) System.out.println("Dealer shows a " + this + ".");
        else System.out.println("Dealer puts card face down on the table.");
    }

    public int getSuitValue()
    {
        if(this.Suit == Suits.Spades) return 4;
        if(this.Suit == Suits.Hearts) return 3;
        if(this.Suit == Suits.Diamonds) return 2;
        return 1;
    }

    @Override
    public String toString()
    {
        String val = this.Value + "";
        if(this.Value == 1) val = "Ace";
        if(this.Value == 11) val = "Jack";
        if(this.Value == 12) val = "Queen";
        if(this.Value == 13) val = "King";
        return val + " of " + this.Suit;
    }
}
