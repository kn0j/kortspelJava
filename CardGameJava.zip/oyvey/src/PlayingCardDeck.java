import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Date;

public class PlayingCardDeck
{
    static ArrayList<PlayingCard> cards = new ArrayList<>();

    public static void Add(PlayingCard card)
    {
        cards.add(card);
    }

    public static void Shuffle()
    {
        Random rng = new Random();
        for(int i = cards.size()-1; i > 0; i--)
        {
            int tmpPos = Math.abs(rng.nextInt(i+1));
            PlayingCard tmp_card = cards.get(tmpPos);
            cards.set(tmpPos, cards.get(i));
            cards.set(i, tmp_card);
        }
    }

    public static void Print()
    {
        for(PlayingCard card : cards)
        {
            System.out.println(card);
        }
    }

    public static PlayingCard Draw()
    {
        return cards.remove(0);
    }
}
